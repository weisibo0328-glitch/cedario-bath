# CEDARIO Bath

Static first-version showcase site for 香柏卫浴 / CEDARIO.

- English-first public presentation
- Chinese, Thai, Arabic, Japanese, Korean, and Russian language paths
- Bathroom cabinet and toilet series
- Catalog page galleries
- WhatsApp inquiry entry points
- No checkout, price display, membership, or public comments
