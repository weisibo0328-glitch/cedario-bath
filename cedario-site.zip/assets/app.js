(function () {
  const languages = [
    { code: "en", label: "English", native: "English", dir: "ltr" },
    { code: "zh", label: "中文", native: "中文", dir: "ltr" },
    { code: "th", label: "Thai", native: "ไทย", dir: "ltr" },
    { code: "ar", label: "Arabic", native: "العربية", dir: "rtl" },
    { code: "ja", label: "Japanese", native: "日本語", dir: "ltr" },
    { code: "ko", label: "Korean", native: "한국어", dir: "ltr" },
    { code: "ru", label: "Russian", native: "Русский", dir: "ltr" }
  ];

  const langCodes = languages.map((item) => item.code);
  const whatsappNumbers = [
    { label: "+86 13827707256", url: "https://wa.me/8613827707256" },
    { label: "+852 56326853", url: "https://wa.me/85256326853" }
  ];

  const copy = {
    en: {
      brand: "CEDARIO",
      brandSub: "Sanitary Ware",
      nav: { home: "Home", about: "About Us", products: "Products", catalogs: "Catalogs", contact: "Contact" },
      common: {
        whatsapp: "WhatsApp Inquiry",
        products: "Product Series",
        catalogs: "Catalog Materials",
        viewSeries: "View Series",
        viewCatalogs: "View Catalogs",
        contactNow: "Contact Now",
        requestQuote: "Request by WhatsApp",
        representative: "Representative Products",
        gallery: "Series Gallery",
        page: "Page",
        models: "Models",
        comingSoon: "Coming Soon",
        privacy: "Privacy Policy",
        accept: "Accept",
        cookie: "We use essential cookies and reserve analytics interfaces for future traffic insights."
      },
      home: {
        eyebrow: "Own factory + integrated supply chain",
        title: "CEDARIO",
        lede: "A global sanitary ware manufacturing partner presenting bathroom cabinets, toilets, and future multi-category supply capability for B2B buyers.",
        heroLinks: ["Production Scale", "Bathroom Cabinets", "Toilets"],
        strengthTitle: "Built for global B2B supply.",
        strengthCopy: "CEDARIO combines own-factory manufacturing with an integrated supply chain, giving international buyers a broader product range and a more flexible sourcing path.",
        strengths: [
          ["Manufacturing Base", "Factory capability is presented first, with production-scale visuals reserved for future real factory materials."],
          ["Multi-category Range", "Bathroom cabinets and toilets are the first public categories, with interfaces reserved for more sanitary ware lines."],
          ["B2B Cooperation", "The site is designed for distributors, wholesalers, project buyers, and brand sourcing teams."]
        ],
        productsTitle: "Series by category.",
        productsCopy: "Every series is presented through a clear concept, representative models, and a complete visual gallery from the source catalogs.",
        processTitle: "From selection to supply.",
        processCopy: "The first version focuses on product presentation. Inquiry, analytics, SEO, and future conversion interfaces remain ready for later phases."
      },
      about: {
        title: "Sanitary ware manufacturing with a wider supply range.",
        copy: "CEDARIO is the international identity of 香柏卫浴, positioned as a factory-driven partner with strong integrated supply capability. The public website avoids factory address display and focuses on manufacturing credibility, category range, and product presentation.",
        pillars: [
          ["Own Factory", "Core production strength forms the brand foundation and will be expanded with real factory materials."],
          ["Integrated Supply Chain", "A wider product matrix can be presented without limiting the site to one single category."],
          ["Quality Process", "Production, inspection, packaging, and warehousing sections are reserved for verified materials."],
          ["Global Communication", "English-first presentation with Chinese, Thai, Arabic, Japanese, Korean, and Russian versions."]
        ]
      },
      productsPage: {
        title: "Bathroom cabinets first, toilets second, more sanitary ware reserved.",
        copy: "The first version uses series concepts and representative models, while all catalog visuals are classified into galleries for complete presentation.",
        future: "Other sanitary ware categories will be added after the first version."
      },
      series: {
        cabinetsTitle: "Bathroom Cabinet Series",
        cabinetsCopy: "High-end minimalist bath furniture with stainless steel, aluminum alloy, solid-wood-look, ceramic basin, rock-slab, mirror cabinet, lighting, defogging, and storage options.",
        toiletsTitle: "Toilet Series",
        toiletsCopy: "A practical toilet range for B2B selection, including multiple one-piece models and smart toilet configurations across standard, premium, and top specifications.",
        futureTitle: "Reserved Sanitary Ware Interface",
        futureCopy: "Additional bathroom products can be added to the same product architecture later."
      },
      catalogsPage: {
        title: "Complete catalog image galleries.",
        copy: "All available pages from the three source catalogs are classified into product galleries. Original third-party brand marks are visually covered in the web presentation with CEDARIO identity."
      },
      contact: {
        title: "Contact CEDARIO",
        copy: "Product prices are not displayed on the first version. Please select either WhatsApp number for product inquiry, catalog discussion, and B2B cooperation.",
        emailNote: "Email interface is reserved for later conversion workflows."
      },
      privacy: {
        title: "Privacy Policy",
        copy: "This first version is a product-display website. It does not provide checkout, membership registration, or public comments.",
        blocks: [
          ["Contact Data", "When you contact CEDARIO through WhatsApp or email, the information you send is used only for communication and inquiry follow-up."],
          ["Analytics Interfaces", "Google Analytics and Google Search Console interfaces are reserved and will be connected after the formal domain is activated."],
          ["Cookies", "The site may use essential cookies and a basic cookie notice. Marketing tracking is not active in the first version."],
          ["Inquiry Form", "The inquiry form interface is reserved but hidden in the first version."]
        ]
      }
    },
    zh: {
      brand: "香柏卫浴",
      brandSub: "卫浴制造工厂",
      nav: { home: "首页", about: "关于工厂", products: "产品系列", catalogs: "图册资料", contact: "联系我们" },
      common: {
        whatsapp: "WhatsApp 咨询",
        products: "产品系列",
        catalogs: "图册资料",
        viewSeries: "查看系列",
        viewCatalogs: "查看图册",
        contactNow: "立即联系",
        requestQuote: "WhatsApp 询价",
        representative: "代表产品",
        gallery: "系列图库",
        page: "第",
        models: "型号",
        comingSoon: "即将推出",
        privacy: "隐私政策",
        accept: "同意",
        cookie: "本站使用必要 Cookie，并预留统计接口用于后续访问分析。"
      },
      home: {
        eyebrow: "自有工厂 + 强大整合供应链",
        title: "香柏卫浴",
        lede: "面向全球 B 端客户的卫浴制造伙伴，第一版重点展示浴室柜、坐便器及后续多品类供应能力。",
        heroLinks: ["生产规模", "浴室柜", "坐便器"],
        strengthTitle: "为全球 B 端供应而建立。",
        strengthCopy: "香柏卫浴以自有工厂为基础，结合强大的整合供应链，为海外客户提供更完整的品类和更灵活的选品方式。",
        strengths: [
          ["工厂制造基础", "首页优先呈现工厂实力，并为后续真实生产规模资料预留主视觉位置。"],
          ["多品类覆盖", "第一版公开浴室柜和坐便器，其他卫浴品类保留扩展入口。"],
          ["B 端合作", "面向经销商、批发商、工程采购和品牌采购团队。"]
        ],
        productsTitle: "按品类展示系列。",
        productsCopy: "每个系列以系列理念、代表型号和完整图库呈现，方便客户快速理解产品方向。",
        processTitle: "从选品到供应。",
        processCopy: "第一版以产品展示为核心，同时预留询盘、统计、SEO 和后续转化接口。"
      },
      about: {
        title: "拥有更完整供应范围的卫浴制造工厂。",
        copy: "CEDARIO 是香柏卫浴的国际化名称。网站以工厂实力、品类丰富和供应链能力为核心，不展示工厂地址。",
        pillars: [
          ["自有工厂", "以制造能力作为品牌基础，后续补充真实工厂实拍与生产资料。"],
          ["整合供应链", "网站不局限于单一品类，可逐步扩展更多卫浴用品。"],
          ["质量流程", "预留生产、质检、包装、仓储等模块，等待真实资料补齐。"],
          ["国际化沟通", "英文优先，并同步中文、泰语、阿拉伯语、日语、韩语、俄语版本。"]
        ]
      },
      productsPage: {
        title: "浴室柜优先，坐便器其次，其他卫浴品类预留。",
        copy: "第一版采用系列理念和代表型号展示，并把所有图册图片分配进入对应图库。",
        future: "其他卫浴用品将在第二阶段继续补充。"
      },
      series: {
        cabinetsTitle: "浴室柜系列",
        cabinetsCopy: "高端极简浴室家具，覆盖不锈钢、铝合金、实木免漆、陶瓷一体盆、岩板台面、镜柜、灯光、除雾与收纳等方向。",
        toiletsTitle: "坐便器系列",
        toiletsCopy: "面向 B 端选品的一体式坐便器和智能坐便器产品线，覆盖简配、标配、高配和顶配。",
        futureTitle: "其他卫浴品类接口",
        futureCopy: "后续新增产品可以沿用当前产品结构继续扩展。"
      },
      catalogsPage: {
        title: "完整图册图片资料。",
        copy: "三本来源图册的全部页面已按品类分类进入网站图库。网页展示中会统一覆盖为 CEDARIO / 香柏卫浴品牌识别。"
      },
      contact: {
        title: "联系香柏卫浴",
        copy: "第一版不展示价格。客户可通过任一 WhatsApp 号码咨询产品、图册和 B 端合作。",
        emailNote: "邮件接口已预留，用于后续转化流程。"
      },
      privacy: {
        title: "隐私政策",
        copy: "第一版为产品展示网站，不提供在线支付、会员注册或评论功能。",
        blocks: [
          ["联系信息", "当客户通过 WhatsApp 或邮件联系时，发送的信息仅用于沟通和询盘跟进。"],
          ["统计接口", "Google Analytics 和 Google Search Console 接口已预留，正式域名启用后再绑定。"],
          ["Cookie", "网站可能使用必要 Cookie 和基础提示，第一版不启用投流追踪。"],
          ["询盘表单", "询盘表单接口保留，但第一版暂时隐藏。"]
        ]
      }
    },
    th: {
      brand: "CEDARIO",
      brandSub: "สุขภัณฑ์",
      nav: { home: "หน้าแรก", about: "โรงงาน", products: "สินค้า", catalogs: "แคตตาล็อก", contact: "ติดต่อ" },
      common: { whatsapp: "สอบถาม WhatsApp", products: "ซีรีส์สินค้า", catalogs: "แคตตาล็อก", viewSeries: "ดูซีรีส์", viewCatalogs: "ดูแคตตาล็อก", contactNow: "ติดต่อ", requestQuote: "ขอข้อมูลทาง WhatsApp", representative: "สินค้าตัวแทน", gallery: "แกลเลอรี", page: "หน้า", models: "รุ่น", comingSoon: "เร็วๆ นี้", privacy: "นโยบายความเป็นส่วนตัว", accept: "ยอมรับ", cookie: "เว็บไซต์ใช้คุกกี้ที่จำเป็นและเตรียมระบบสถิติสำหรับอนาคต" },
      home: { eyebrow: "โรงงานของเรา + ซัพพลายเชนแบบครบวงจร", title: "CEDARIO", lede: "พันธมิตรผู้ผลิตสุขภัณฑ์สำหรับลูกค้า B2B ทั่วโลก เน้นตู้ห้องน้ำ โถสุขภัณฑ์ และความสามารถด้านสินค้าหลากหมวด", heroLinks: ["กำลังผลิต", "ตู้ห้องน้ำ", "โถสุขภัณฑ์"], strengthTitle: "สร้างขึ้นเพื่อซัพพลาย B2B ระดับโลก", strengthCopy: "CEDARIO ผสานฐานการผลิตของโรงงานกับซัพพลายเชนที่กว้าง เพื่อช่วยผู้ซื้อเลือกสินค้าได้ยืดหยุ่นขึ้น", strengths: [["ฐานการผลิต", "พื้นที่ภาพกำลังผลิตพร้อมรอรูปโรงงานจริงในขั้นต่อไป"], ["สินค้าหลากหมวด", "เริ่มจากตู้ห้องน้ำและโถสุขภัณฑ์ พร้อมรองรับหมวดอื่น"], ["ความร่วมมือ B2B", "เหมาะกับตัวแทนจำหน่าย ผู้ค้าส่ง โครงการ และทีมจัดซื้อแบรนด์"]], productsTitle: "ซีรีส์ตามหมวดสินค้า", productsCopy: "แต่ละซีรีส์มีแนวคิด รุ่นตัวแทน และแกลเลอรีจากแคตตาล็อก", processTitle: "จากการเลือกสินค้าไปสู่การจัดหา", processCopy: "เวอร์ชันแรกเน้นการนำเสนอสินค้า พร้อมเตรียมช่องทางสอบถาม สถิติ SEO และการต่อยอดในอนาคต" },
      about: { title: "ผู้ผลิตสุขภัณฑ์พร้อมซัพพลายที่กว้างขึ้น", copy: "CEDARIO คือชื่อสากลของ香柏卫浴 นำเสนอความน่าเชื่อถือของโรงงาน ความหลากหลายสินค้า และซัพพลายเชน โดยไม่แสดงที่อยู่โรงงาน", pillars: [["โรงงานของเรา", "ใช้ความสามารถด้านการผลิตเป็นฐานของแบรนด์"], ["ซัพพลายเชนครบ", "รองรับการขยายหมวดสินค้าเพิ่มเติม"], ["กระบวนการคุณภาพ", "เตรียมพื้นที่สำหรับการผลิต ตรวจสอบ บรรจุ และคลังสินค้า"], ["สื่อสารหลายภาษา", "อังกฤษเป็นหลัก พร้อมจีน ไทย อาหรับ ญี่ปุ่น เกาหลี และรัสเซีย"]] },
      productsPage: { title: "ตู้ห้องน้ำมาก่อน โถสุขภัณฑ์ตามมา และรองรับสินค้าอื่น", copy: "เวอร์ชันแรกใช้แนวคิดซีรีส์ รุ่นตัวแทน และรูปจากแคตตาล็อกทั้งหมด", future: "หมวดสุขภัณฑ์อื่นจะเพิ่มในระยะต่อไป" },
      series: { cabinetsTitle: "ซีรีส์ตู้ห้องน้ำ", cabinetsCopy: "เฟอร์นิเจอร์ห้องน้ำสไตล์มินิมอลระดับสูง พร้อมวัสดุและฟังก์ชันหลากหลาย", toiletsTitle: "ซีรีส์โถสุขภัณฑ์", toiletsCopy: "กลุ่มโถสุขภัณฑ์สำหรับการเลือกสินค้า B2B รวมรุ่นทั่วไปและรุ่นอัจฉริยะ", futureTitle: "ช่องทางสำหรับหมวดอื่น", futureCopy: "สามารถเพิ่มสินค้าใหม่โดยใช้โครงสร้างเดิม" },
      catalogsPage: { title: "แกลเลอรีแคตตาล็อกครบถ้วน", copy: "ทุกหน้าจากแคตตาล็อกต้นทางถูกจัดหมวดในเว็บไซต์ พร้อมแสดงเอกลักษณ์ CEDARIO" },
      contact: { title: "ติดต่อ CEDARIO", copy: "เวอร์ชันแรกไม่แสดงราคา กรุณาเลือก WhatsApp เพื่อสอบถามสินค้าและความร่วมมือ B2B", emailNote: "ช่องทางอีเมลเตรียมไว้สำหรับขั้นต่อไป" },
      privacy: { title: "นโยบายความเป็นส่วนตัว", copy: "เว็บไซต์เวอร์ชันแรกใช้เพื่อแสดงสินค้า ไม่มีชำระเงิน สมัครสมาชิก หรือความคิดเห็น", blocks: [["ข้อมูลติดต่อ", "ข้อมูลที่ส่งผ่าน WhatsApp หรืออีเมลใช้เพื่อการสื่อสารและติดตามคำถาม"], ["ระบบสถิติ", "เตรียม Google Analytics และ Search Console สำหรับโดเมนจริง"], ["คุกกี้", "ใช้คุกกี้ที่จำเป็นและยังไม่เปิดระบบโฆษณา"], ["แบบฟอร์มสอบถาม", "เตรียมไว้แต่ซ่อนไว้ในเวอร์ชันแรก"]] }
    },
    ar: {
      brand: "CEDARIO",
      brandSub: "الأدوات الصحية",
      nav: { home: "الرئيسية", about: "عن المصنع", products: "المنتجات", catalogs: "الكتالوجات", contact: "تواصل" },
      common: { whatsapp: "استفسار واتساب", products: "سلاسل المنتجات", catalogs: "مواد الكتالوج", viewSeries: "عرض السلسلة", viewCatalogs: "عرض الكتالوج", contactNow: "تواصل الآن", requestQuote: "استفسر عبر واتساب", representative: "منتجات مختارة", gallery: "معرض السلسلة", page: "صفحة", models: "الموديلات", comingSoon: "قريبا", privacy: "سياسة الخصوصية", accept: "موافق", cookie: "نستخدم ملفات تعريف ارتباط أساسية ونجهز واجهات التحليلات للمستقبل." },
      home: { eyebrow: "مصنع خاص + سلسلة توريد متكاملة", title: "CEDARIO", lede: "شريك تصنيع أدوات صحية لعملاء B2B حول العالم، مع عرض خزائن الحمام والمراحيض وقدرة توريد متعددة الفئات.", heroLinks: ["حجم الإنتاج", "خزائن الحمام", "المراحيض"], strengthTitle: "مصمم للتوريد العالمي B2B.", strengthCopy: "تجمع CEDARIO بين التصنيع المباشر وسلسلة توريد متكاملة لتقديم نطاق أوسع من المنتجات للمشترين الدوليين.", strengths: [["قاعدة تصنيع", "تم تخصيص مساحة مرئية لقوة المصنع ومواد الإنتاج الحقيقية لاحقا."], ["فئات متعددة", "تبدأ النسخة الأولى بخزائن الحمام والمراحيض مع واجهات لفئات أخرى."], ["تعاون B2B", "مناسب للموزعين وتجار الجملة والمشاريع وفرق الشراء."]], productsTitle: "السلاسل حسب الفئة.", productsCopy: "كل سلسلة تعرض الفكرة والموديلات المختارة ومعرض الصور الكامل.", processTitle: "من الاختيار إلى التوريد.", processCopy: "تركز النسخة الأولى على عرض المنتجات مع تجهيز الاستفسار والتحليلات و SEO للمراحل التالية." },
      about: { title: "تصنيع أدوات صحية بنطاق توريد أوسع.", copy: "CEDARIO هو الاسم الدولي لـ香柏卫浴. يركز الموقع على موثوقية المصنع وتنوع الفئات وقوة سلسلة التوريد دون عرض عنوان المصنع.", pillars: [["مصنع خاص", "قدرة التصنيع هي أساس العلامة وسيتم دعمها بمواد حقيقية لاحقا."], ["سلسلة توريد متكاملة", "يمكن توسيع الموقع إلى فئات صحية إضافية."], ["عملية الجودة", "تم حجز أقسام للإنتاج والفحص والتعبئة والتخزين."], ["تواصل عالمي", "الإنجليزية أولا مع الصينية والتايلاندية والعربية واليابانية والكورية والروسية."]] },
      productsPage: { title: "خزائن الحمام أولا، المراحيض ثانيا، وفئات أخرى لاحقا.", copy: "تستخدم النسخة الأولى فكرة السلسلة والموديلات المختارة وجميع صور الكتالوج المصنفة.", future: "ستضاف فئات الأدوات الصحية الأخرى في المرحلة التالية." },
      series: { cabinetsTitle: "سلسلة خزائن الحمام", cabinetsCopy: "أثاث حمام بسيط وفاخر بخيارات مواد ووظائف متعددة.", toiletsTitle: "سلسلة المراحيض", toiletsCopy: "مجموعة مراحيض عملية لاختيار B2B، تشمل موديلات عادية وذكية بمستويات مختلفة.", futureTitle: "واجهة فئات محجوزة", futureCopy: "يمكن إضافة منتجات جديدة بنفس هيكل الموقع." },
      catalogsPage: { title: "معارض صور كتالوج كاملة.", copy: "تم تصنيف كل الصفحات المتاحة من الكتالوجات الثلاثة داخل الموقع مع هوية CEDARIO." },
      contact: { title: "تواصل مع CEDARIO", copy: "لا تعرض الأسعار في النسخة الأولى. اختر أي رقم واتساب للاستفسار عن المنتجات والتعاون B2B.", emailNote: "واجهة البريد الإلكتروني محجوزة لمرحلة لاحقة." },
      privacy: { title: "سياسة الخصوصية", copy: "هذه النسخة موقع عرض منتجات فقط، بدون دفع أو عضوية أو تعليقات.", blocks: [["بيانات التواصل", "تستخدم معلومات واتساب أو البريد للتواصل ومتابعة الاستفسارات فقط."], ["واجهات التحليلات", "تم حجز Google Analytics و Search Console بعد تفعيل الدومين الرسمي."], ["ملفات تعريف الارتباط", "قد يستخدم الموقع ملفات ضرورية ولا توجد حملات إعلانية في النسخة الأولى."], ["نموذج الاستفسار", "واجهة النموذج محجوزة لكنها مخفية في النسخة الأولى."]] }
    },
    ja: {
      brand: "CEDARIO",
      brandSub: "衛浴メーカー",
      nav: { home: "ホーム", about: "工場紹介", products: "製品", catalogs: "カタログ", contact: "お問い合わせ" },
      common: { whatsapp: "WhatsApp 相談", products: "製品シリーズ", catalogs: "カタログ資料", viewSeries: "シリーズを見る", viewCatalogs: "カタログを見る", contactNow: "問い合わせ", requestQuote: "WhatsApp で相談", representative: "代表製品", gallery: "シリーズギャラリー", page: "ページ", models: "型番", comingSoon: "近日公開", privacy: "プライバシー", accept: "同意", cookie: "必要な Cookie を使用し、将来の分析機能を準備しています。" },
      home: { eyebrow: "自社工場 + 統合サプライチェーン", title: "CEDARIO", lede: "世界の B2B 向けに、洗面化粧台、トイレ、将来の多品類供給力を提示する衛浴製造パートナーです。", heroLinks: ["生産規模", "洗面化粧台", "トイレ"], strengthTitle: "グローバル B2B 供給のために。", strengthCopy: "CEDARIO は自社製造と統合サプライチェーンを組み合わせ、海外バイヤーへ幅広い選択肢を提供します。", strengths: [["製造基盤", "生産規模の主ビジュアルは、実写資料追加に備えています。"], ["多品類展開", "第一版は洗面化粧台とトイレを公開し、他カテゴリーを予約します。"], ["B2B 協力", "販売代理店、卸、プロジェクト、ブランド調達向けです。"]], productsTitle: "カテゴリー別シリーズ。", productsCopy: "各シリーズはコンセプト、代表型番、完全ギャラリーで構成します。", processTitle: "選定から供給まで。", processCopy: "第一版は製品展示を中心に、問い合わせ、分析、SEO、将来の転換導線を準備します。" },
      about: { title: "より広い供給範囲を持つ衛浴製造工場。", copy: "CEDARIO は香柏卫浴の国際名です。工場住所は表示せず、製造信頼性、品類、サプライチェーン力を中心に伝えます。", pillars: [["自社工場", "製造力をブランドの基盤として提示します。"], ["統合サプライチェーン", "単一品類に限定せず拡張できます。"], ["品質プロセス", "生産、検査、梱包、倉庫の資料追加を予約します。"], ["多言語対応", "英語を優先し、中国語、タイ語、アラビア語、日本語、韓国語、ロシア語に対応します。"]] },
      productsPage: { title: "洗面化粧台を優先、次にトイレ、他衛浴品類を予約。", copy: "第一版ではシリーズ理念、代表型番、全カタログ画像を分類して表示します。", future: "他の衛浴製品は第二段階で追加します。" },
      series: { cabinetsTitle: "洗面化粧台シリーズ", cabinetsCopy: "高級ミニマルな浴室家具。多様な素材、洗面ボウル、鏡収納、照明、防曇、収納機能に対応します。", toiletsTitle: "トイレシリーズ", toiletsCopy: "B2B 選定向けの一体型トイレとスマートトイレの製品群です。", futureTitle: "予約カテゴリー", futureCopy: "新製品は現在の構造で追加できます。" },
      catalogsPage: { title: "完全なカタログ画像ギャラリー。", copy: "三つの元カタログの全ページを分類し、CEDARIO のブランド表示で掲載します。" },
      contact: { title: "CEDARIO へ問い合わせ", copy: "第一版では価格を表示しません。WhatsApp から製品や B2B 協力についてご相談ください。", emailNote: "メール導線は今後のために予約しています。" },
      privacy: { title: "プライバシーポリシー", copy: "第一版は製品展示サイトで、決済、会員登録、コメント機能はありません。", blocks: [["連絡情報", "WhatsApp やメールで送信された情報は、連絡と問い合わせ対応のみに使用します。"], ["分析機能", "正式ドメイン後に Google Analytics と Search Console を接続します。"], ["Cookie", "必要な Cookie を使用する場合があります。第一版で広告追跡は有効化しません。"], ["問い合わせフォーム", "フォーム導線は予約し、第一版では非表示です。"]] }
    },
    ko: {
      brand: "CEDARIO",
      brandSub: "욕실 제조",
      nav: { home: "홈", about: "공장 소개", products: "제품", catalogs: "카탈로그", contact: "문의" },
      common: { whatsapp: "WhatsApp 문의", products: "제품 시리즈", catalogs: "카탈로그", viewSeries: "시리즈 보기", viewCatalogs: "카탈로그 보기", contactNow: "문의하기", requestQuote: "WhatsApp 문의", representative: "대표 제품", gallery: "시리즈 갤러리", page: "페이지", models: "모델", comingSoon: "출시 예정", privacy: "개인정보", accept: "동의", cookie: "필수 쿠키를 사용하며 향후 분석 인터페이스를 준비합니다." },
      home: { eyebrow: "자체 공장 + 통합 공급망", title: "CEDARIO", lede: "글로벌 B2B 고객을 위한 욕실 제조 파트너로, 욕실장, 양변기, 향후 다품목 공급 능력을 제시합니다.", heroLinks: ["생산 규모", "욕실장", "양변기"], strengthTitle: "글로벌 B2B 공급을 위해 설계되었습니다.", strengthCopy: "CEDARIO 는 자체 제조와 통합 공급망을 결합해 해외 바이어에게 폭넓은 선택을 제공합니다.", strengths: [["제조 기반", "실제 공장 자료 추가를 위한 생산 규모 영역을 준비했습니다."], ["다품목 구성", "첫 버전은 욕실장과 양변기를 공개하고 다른 품목을 예약합니다."], ["B2B 협력", "유통, 도매, 프로젝트, 브랜드 소싱 팀에 적합합니다."]], productsTitle: "카테고리별 시리즈", productsCopy: "각 시리즈는 콘셉트, 대표 모델, 전체 갤러리로 구성됩니다.", processTitle: "선택에서 공급까지", processCopy: "첫 버전은 제품 전시에 집중하고 문의, 분석, SEO, 향후 전환 인터페이스를 준비합니다." },
      about: { title: "더 넓은 공급 범위를 가진 욕실 제조 공장", copy: "CEDARIO 는 香柏卫浴의 국제 이름입니다. 공장 주소는 표시하지 않고 제조 신뢰도, 제품 범위, 공급망 역량을 중심으로 보여줍니다.", pillars: [["자체 공장", "제조 역량을 브랜드 기반으로 제시합니다."], ["통합 공급망", "단일 품목에 제한되지 않고 확장 가능합니다."], ["품질 프로세스", "생산, 검사, 포장, 창고 자료 영역을 예약했습니다."], ["다국어 소통", "영어 우선, 중국어, 태국어, 아랍어, 일본어, 한국어, 러시아어 지원."]] },
      productsPage: { title: "욕실장 우선, 양변기 다음, 기타 욕실 제품 예약", copy: "첫 버전은 시리즈 콘셉트, 대표 모델, 전체 카탈로그 이미지를 분류해 보여줍니다.", future: "기타 욕실 제품은 다음 단계에서 추가됩니다." },
      series: { cabinetsTitle: "욕실장 시리즈", cabinetsCopy: "고급 미니멀 욕실 가구로 다양한 소재, 세면대, 거울장, 조명, 김서림 방지, 수납 옵션을 제공합니다.", toiletsTitle: "양변기 시리즈", toiletsCopy: "B2B 선택을 위한 일체형 양변기와 스마트 양변기 제품군입니다.", futureTitle: "예약 제품군", futureCopy: "새 제품은 현재 구조로 쉽게 추가할 수 있습니다." },
      catalogsPage: { title: "전체 카탈로그 이미지 갤러리", copy: "세 개의 원본 카탈로그 전체 페이지를 제품별로 분류하고 CEDARIO 브랜드로 표시합니다." },
      contact: { title: "CEDARIO 문의", copy: "첫 버전에서는 가격을 표시하지 않습니다. WhatsApp 번호를 선택해 제품과 B2B 협력을 문의하세요.", emailNote: "이메일 인터페이스는 이후 전환 흐름을 위해 예약됩니다." },
      privacy: { title: "개인정보 처리방침", copy: "첫 버전은 제품 전시 사이트이며 결제, 회원가입, 댓글 기능이 없습니다.", blocks: [["연락 정보", "WhatsApp 또는 이메일로 보낸 정보는 소통과 문의 대응에만 사용됩니다."], ["분석 인터페이스", "정식 도메인 활성화 후 Google Analytics 및 Search Console 을 연결합니다."], ["쿠키", "필수 쿠키를 사용할 수 있으며 첫 버전에서는 광고 추적을 사용하지 않습니다."], ["문의 양식", "문의 양식 인터페이스는 예약되어 있지만 첫 버전에서는 숨겨집니다."]] }
    },
    ru: {
      brand: "CEDARIO",
      brandSub: "Сантехника",
      nav: { home: "Главная", about: "О фабрике", products: "Продукты", catalogs: "Каталоги", contact: "Контакты" },
      common: { whatsapp: "Запрос WhatsApp", products: "Серии", catalogs: "Каталоги", viewSeries: "Смотреть серию", viewCatalogs: "Смотреть каталоги", contactNow: "Связаться", requestQuote: "Запросить в WhatsApp", representative: "Ключевые модели", gallery: "Галерея серии", page: "Страница", models: "Модели", comingSoon: "Скоро", privacy: "Конфиденциальность", accept: "Принять", cookie: "Мы используем необходимые cookie и оставляем интерфейсы аналитики для будущего." },
      home: { eyebrow: "Собственная фабрика + интегрированная цепочка поставок", title: "CEDARIO", lede: "Производственный партнер сантехники для глобальных B2B клиентов: мебель для ванной, унитазы и будущий многокатегорийный ассортимент.", heroLinks: ["Масштаб производства", "Мебель для ванной", "Унитазы"], strengthTitle: "Создано для глобальных B2B поставок.", strengthCopy: "CEDARIO сочетает собственное производство и широкую цепочку поставок, помогая международным покупателям выбирать гибче.", strengths: [["Производственная база", "Основной визуальный блок зарезервирован для реальных материалов фабрики."], ["Много категорий", "Первая версия показывает мебель для ванной и унитазы, остальные категории зарезервированы."], ["B2B сотрудничество", "Для дистрибьюторов, оптовиков, проектных покупателей и закупочных команд брендов."]], productsTitle: "Серии по категориям.", productsCopy: "Каждая серия содержит концепцию, ключевые модели и полную галерею из каталогов.", processTitle: "От выбора к поставке.", processCopy: "Первая версия фокусируется на презентации продукции и готовит интерфейсы запросов, аналитики, SEO и будущей конверсии." },
      about: { title: "Производство сантехники с широкими возможностями поставок.", copy: "CEDARIO - международное имя 香柏卫浴. Сайт показывает надежность фабрики, ассортимент и цепочку поставок без публикации адреса фабрики.", pillars: [["Собственная фабрика", "Производственные возможности являются основой бренда."], ["Интегрированная поставка", "Сайт может расширяться на новые категории сантехники."], ["Контроль качества", "Разделы производства, проверки, упаковки и склада зарезервированы."], ["Много языков", "Английский в приоритете, также китайский, тайский, арабский, японский, корейский и русский."]] },
      productsPage: { title: "Сначала мебель для ванной, затем унитазы, далее другие категории.", copy: "Первая версия использует концепции серий, ключевые модели и все изображения каталогов в классифицированных галереях.", future: "Другие категории сантехники будут добавлены на втором этапе." },
      series: { cabinetsTitle: "Серия мебели для ванной", cabinetsCopy: "Премиальная минималистичная мебель для ванной с разными материалами, раковинами, зеркальными шкафами, светом, антизапотеванием и хранением.", toiletsTitle: "Серия унитазов", toiletsCopy: "Практичная линейка для B2B выбора, включая обычные и умные модели разных уровней комплектации.", futureTitle: "Резерв для новых категорий", futureCopy: "Новые продукты можно добавить в текущую структуру." },
      catalogsPage: { title: "Полные галереи каталогов.", copy: "Все страницы трех исходных каталогов классифицированы в галереях сайта и показаны с идентичностью CEDARIO." },
      contact: { title: "Связаться с CEDARIO", copy: "В первой версии цены не публикуются. Выберите любой номер WhatsApp для запроса по продукции и B2B сотрудничеству.", emailNote: "Email интерфейс зарезервирован для будущей конверсии." },
      privacy: { title: "Политика конфиденциальности", copy: "Первая версия является сайтом презентации продукции, без оплаты, регистрации и комментариев.", blocks: [["Контактные данные", "Информация, отправленная через WhatsApp или email, используется только для связи и обработки запросов."], ["Аналитика", "Google Analytics и Search Console будут подключены после запуска официального домена."], ["Cookie", "Сайт может использовать необходимые cookie; рекламное отслеживание не активно."], ["Форма запроса", "Интерфейс формы зарезервирован, но скрыт в первой версии."]] }
    }
  };

  const seriesCards = (t) => [
    {
      title: t.series.cabinetsTitle,
      copy: t.series.cabinetsCopy,
      image: "../assets/catalog-pages/digital/page-02.jpg",
      href: "bathroom-cabinets.html",
      tags: ["2652", "2660", "JY-149"],
      label: "01"
    },
    {
      title: t.series.toiletsTitle,
      copy: t.series.toiletsCopy,
      image: "../assets/catalog-pages/toilets/page-02.jpg",
      href: "toilets.html",
      tags: ["JY-7711", "JY-7751", "JY-806"],
      label: "02"
    },
    {
      title: t.series.futureTitle,
      copy: t.series.futureCopy,
      image: "../assets/catalog-pages/digital/page-01.jpg",
      href: "products.html#future",
      tags: [t.common.comingSoon],
      label: "03"
    }
  ];

  const representativeCabinets = (t) => [
    { code: "2652", title: "Song Aesthetic Cabinet", image: "../assets/catalog-pages/digital/page-02.jpg", copy: "Rock-slab and ceramic basin combinations with warm wood visual language." },
    { code: "2660", title: "Mirror Storage Cabinet", image: "../assets/catalog-pages/digital/page-03.jpg", copy: "Lighting, defogging, tissue opening, make-up storage, and hairdryer storage." },
    { code: "2659", title: "Soft Modern Cabinet", image: "../assets/catalog-pages/digital/page-05.jpg", copy: "Modern cream-style color direction with integrated ceramic basin." },
    { code: "JY-149", title: "Pearl Grey Stainless Cabinet", image: "../assets/catalog-pages/bath-cabinets/page-02.jpg", copy: "Stainless steel door panel series in 600, 700, and 800 mm options." },
    { code: "JY-3175", title: "Full Stainless Cabinet", image: "../assets/catalog-pages/bath-cabinets/page-07.jpg", copy: "Durable stainless steel cabinet and mirror cabinet for practical B2B supply." },
    { code: "JY-6638", title: "Seamless Door Cabinet", image: "../assets/catalog-pages/bath-cabinets/page-12.jpg", copy: "High-temperature ceramic basin with smart touch light and defog mirror options." }
  ];

  const representativeToilets = () => [
    { code: "JY-7711", title: "One-piece Toilet", image: "../assets/catalog-pages/toilets/page-02.jpg", copy: "Clean one-piece form for distributor and project selection." },
    { code: "JY-7751", title: "Dual-option Toilet", image: "../assets/catalog-pages/toilets/page-02.jpg", copy: "Flexible configuration for different market requirements." },
    { code: "JY-7881", title: "Compact Toilet", image: "../assets/catalog-pages/toilets/page-04.jpg", copy: "Minimal ceramic profile for modern bathroom projects." },
    { code: "JY-806", title: "Smart Toilet", image: "../assets/catalog-pages/toilets/page-05.jpg", copy: "Available across simple, standard, premium, and top configurations." },
    { code: "JY-836", title: "Smart Toilet", image: "../assets/catalog-pages/toilets/page-06.jpg", copy: "Gunmetal finish option with layered specification levels." },
    { code: "JY-826", title: "Smart Toilet", image: "../assets/catalog-pages/toilets/page-07.jpg", copy: "Titanium silver and white options for premium product selection." }
  ];

  const catalogGroups = [
    { key: "digital", title: "Design Bath Cabinet Catalog", subtitle: "59 pages", image: "../assets/catalog-pages/digital/page-01.jpg" },
    { key: "bath-cabinets", title: "Bathroom Cabinet Manufacturing Catalog", subtitle: "56 pages", image: "../assets/catalog-pages/bath-cabinets/page-02.jpg" },
    { key: "toilets", title: "Toilet Catalog", subtitle: "20 pages", image: "../assets/catalog-pages/toilets/page-02.jpg" }
  ];

  let catalogData = null;

  const state = getRouteState();
  const t = copy[state.lang] || copy.en;
  const langMeta = languages.find((item) => item.code === state.lang) || languages[0];

  document.documentElement.lang = state.lang;
  document.documentElement.dir = langMeta.dir;
  document.body.dir = langMeta.dir;

  fetch("../assets/catalog-data.json")
    .then((response) => response.json())
    .then((data) => {
      catalogData = data;
      render();
    })
    .catch(() => {
      catalogData = {};
      render();
    });

  function getRouteState() {
    const parts = window.location.pathname.split("/").filter(Boolean);
    let index = parts.findIndex((part) => langCodes.includes(part));
    if (index === -1) index = 0;
    const lang = langCodes.includes(parts[index]) ? parts[index] : "en";
    const pagePart = parts[index + 1] || "index.html";
    const page = pagePart.replace(/\.html$/, "") || "index";
    const baseParts = langCodes.includes(parts[index]) ? parts.slice(0, index) : parts.slice(0, 0);
    const base = `/${baseParts.join("/")}${baseParts.length ? "/" : ""}`;
    return { lang, page, file: pagePart.includes(".") ? pagePart : "index.html", base };
  }

  function localUrl(lang, file) {
    return `${state.base}${lang}/${file}`;
  }

  function render() {
    const app = document.getElementById("app");
    app.innerHTML = `
      <div class="site-shell">
        ${renderHeader()}
        <main>${renderPage()}</main>
        ${renderFooter()}
        ${renderFloatingWhatsApp()}
        ${renderCookieBar()}
      </div>
    `;
    bindEvents();
    updateTitle();
  }

  function renderHeader() {
    const links = [
      ["index", t.nav.home, "index.html"],
      ["about", t.nav.about, "about.html"],
      ["products", t.nav.products, "products.html"],
      ["catalogs", t.nav.catalogs, "catalogs.html"],
      ["contact", t.nav.contact, "contact.html"]
    ];
    return `
      <header class="topbar">
        <div class="nav-inner">
          <a class="brand" href="${localUrl(state.lang, "index.html")}" aria-label="${escapeHtml(t.brand)}">
            <span class="brand-mark">${escapeHtml(t.brand)}</span>
            <span class="brand-sub">${escapeHtml(t.brandSub)}</span>
          </a>
          <button class="icon-button" type="button" data-menu aria-label="Menu"><span></span></button>
          <nav class="nav-links" aria-label="Primary">
            ${links.map(([key, label, file]) => `<a href="${localUrl(state.lang, file)}" ${isActive(key) ? "aria-current=\"page\"" : ""}>${escapeHtml(label)}</a>`).join("")}
          </nav>
          <div class="nav-actions">
            <select class="language-select" data-language aria-label="Language">
              ${languages.map((language) => `<option value="${language.code}" ${language.code === state.lang ? "selected" : ""}>${escapeHtml(language.native)}</option>`).join("")}
            </select>
          </div>
        </div>
      </header>
    `;
  }

  function renderPage() {
    switch (state.page) {
      case "about": return renderAboutPage();
      case "products": return renderProductsPage();
      case "bathroom-cabinets": return renderCabinetPage();
      case "toilets": return renderToiletPage();
      case "catalogs": return renderCatalogsPage();
      case "contact": return renderContactPage();
      case "privacy": return renderPrivacyPage();
      default: return renderHomePage();
    }
  }

  function renderHomePage() {
    return `
      <section class="hero" style="--hero-image: url('../assets/catalog-pages/digital/page-02.jpg')">
        <div class="hero-content">
          <span class="eyebrow">${escapeHtml(t.home.eyebrow)}</span>
          <h1>${escapeHtml(t.home.title)}</h1>
          <p class="hero-lede">${escapeHtml(t.home.lede)}</p>
          <div class="hero-actions">
            ${whatsappNumbers.map((item) => `<a class="button primary" href="${withMessage(item.url)}" target="_blank" rel="noopener">${escapeHtml(item.label)}</a>`).join("")}
            <a class="button ghost" href="${localUrl(state.lang, "products.html")}">${escapeHtml(t.common.products)}</a>
          </div>
        </div>
        <div class="hero-index">
          <a href="${localUrl(state.lang, "about.html")}"><span>01</span><strong>${escapeHtml(t.home.heroLinks[0])}</strong></a>
          <a href="${localUrl(state.lang, "bathroom-cabinets.html")}"><span>02</span><strong>${escapeHtml(t.home.heroLinks[1])}</strong></a>
          <a href="${localUrl(state.lang, "toilets.html")}"><span>03</span><strong>${escapeHtml(t.home.heroLinks[2])}</strong></a>
        </div>
      </section>
      <section class="section">
        <div class="inner split">
          <div>
            <span class="section-kicker">CEDARIO</span>
            <h2 class="section-title">${escapeHtml(t.home.strengthTitle)}</h2>
          </div>
          <div>
            <p class="section-copy">${escapeHtml(t.home.strengthCopy)}</p>
            <div class="feature-grid" style="margin-top: 34px;">
              ${t.home.strengths.map(([title, body]) => feature(title, body)).join("")}
            </div>
          </div>
        </div>
      </section>
      <section class="section tight">
        <div class="inner">
          <span class="section-kicker">${escapeHtml(t.common.products)}</span>
          <h2 class="section-title">${escapeHtml(t.home.productsTitle)}</h2>
          <p class="section-copy">${escapeHtml(t.home.productsCopy)}</p>
          <div class="series-grid" style="margin-top: 32px;">
            ${seriesCards(t).map(seriesCard).join("")}
          </div>
        </div>
      </section>
      <section class="section industrial-band">
        <div class="inner split">
          <div>
            <span class="section-kicker">Supply</span>
            <h2 class="section-title">${escapeHtml(t.home.processTitle)}</h2>
            <p class="section-copy">${escapeHtml(t.home.processCopy)}</p>
          </div>
          ${renderTimeline(t.about.pillars)}
        </div>
      </section>
    `;
  }

  function renderAboutPage() {
    return `
      ${pageHero("CEDARIO", t.about.title, t.about.copy)}
      <section class="section">
        <div class="inner">
          ${renderTimeline(t.about.pillars)}
        </div>
      </section>
      <section class="section industrial-band">
        <div class="inner split">
          <div>
            <span class="section-kicker">Production Scale</span>
            <h2 class="section-title">${escapeHtml(t.home.strengthTitle)}</h2>
          </div>
          <div class="feature-grid">
            ${t.home.strengths.map(([title, body]) => feature(title, body)).join("")}
          </div>
        </div>
      </section>
    `;
  }

  function renderProductsPage() {
    return `
      ${pageHero(t.common.products, t.productsPage.title, t.productsPage.copy)}
      <section class="section">
        <div class="inner">
          <div class="series-grid">
            ${seriesCards(t).map(seriesCard).join("")}
          </div>
          <div id="future" class="section-copy" style="margin-top: 28px;">${escapeHtml(t.productsPage.future)}</div>
        </div>
      </section>
    `;
  }

  function renderCabinetPage() {
    return `
      ${pageHero(t.common.products, t.series.cabinetsTitle, t.series.cabinetsCopy)}
      <section class="section">
        <div class="inner">
          <span class="section-kicker">${escapeHtml(t.common.representative)}</span>
          <h2 class="section-title">${escapeHtml(t.common.representative)}</h2>
          <div class="product-grid">${representativeCabinets(t).map(productCard).join("")}</div>
        </div>
      </section>
      ${renderGallerySection(t.common.gallery, ["digital", "bath-cabinets"])}
    `;
  }

  function renderToiletPage() {
    return `
      ${pageHero(t.common.products, t.series.toiletsTitle, t.series.toiletsCopy)}
      <section class="section">
        <div class="inner">
          <span class="section-kicker">${escapeHtml(t.common.representative)}</span>
          <h2 class="section-title">${escapeHtml(t.common.representative)}</h2>
          <div class="product-grid">${representativeToilets().map(productCard).join("")}</div>
        </div>
      </section>
      ${renderGallerySection(t.common.gallery, ["toilets"])}
    `;
  }

  function renderCatalogsPage() {
    return `
      ${pageHero(t.common.catalogs, t.catalogsPage.title, t.catalogsPage.copy)}
      <section class="section">
        <div class="inner">
          <div class="catalog-grid">
            ${catalogGroups.map((group) => catalogCard(group)).join("")}
          </div>
        </div>
      </section>
      ${renderGallerySection(t.common.catalogs, ["digital", "bath-cabinets", "toilets"])}
    `;
  }

  function renderContactPage() {
    return `
      ${pageHero(t.nav.contact, t.contact.title, t.contact.copy)}
      <section class="section">
        <div class="inner contact-grid">
          <div class="contact-card">
            <h3>${escapeHtml(t.common.whatsapp)}</h3>
            <p>${escapeHtml(t.contact.copy)}</p>
            <div class="whatsapp-list">${renderWhatsAppChoices()}</div>
          </div>
          <div class="contact-card">
            <h3>CEDARIO</h3>
            <p>${escapeHtml(t.contact.emailNote)}</p>
            <p class="email-reserve">weisibo0328@gmail.com</p>
          </div>
        </div>
      </section>
    `;
  }

  function renderPrivacyPage() {
    return `
      ${pageHero(t.common.privacy, t.privacy.title, t.privacy.copy)}
      <section class="section">
        <div class="inner privacy-grid">
          ${t.privacy.blocks.map(([title, body]) => `<div class="policy-block"><h3>${escapeHtml(title)}</h3><p>${escapeHtml(body)}</p></div>`).join("")}
        </div>
      </section>
    `;
  }

  function pageHero(kicker, title, body) {
    return `
      <section class="page-hero">
        <div class="inner">
          <span class="section-kicker">${escapeHtml(kicker)}</span>
          <h1 class="section-title">${escapeHtml(title)}</h1>
          <p class="section-copy">${escapeHtml(body)}</p>
        </div>
      </section>
    `;
  }

  function feature(title, body) {
    return `<div class="feature"><strong>${escapeHtml(title)}</strong><p>${escapeHtml(body)}</p></div>`;
  }

  function renderTimeline(items) {
    return `<div class="timeline">${items.map(([title, body]) => `<div><strong>${escapeHtml(title)}</strong><p>${escapeHtml(body)}</p></div>`).join("")}</div>`;
  }

  function seriesCard(card) {
    return `
      <article class="series-card">
        <a class="media brand-cover" href="${localUrl(state.lang, card.href)}"><img src="${card.image}" alt="${escapeHtml(card.title)}" loading="lazy"></a>
        <div class="content">
          <span class="section-kicker">${escapeHtml(card.label)}</span>
          <h3>${escapeHtml(card.title)}</h3>
          <p>${escapeHtml(card.copy)}</p>
          <div class="tags">${card.tags.map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join("")}</div>
          <div class="button-row" style="margin-top: 18px;"><a class="button dark" href="${localUrl(state.lang, card.href)}">${escapeHtml(t.common.viewSeries)}</a></div>
        </div>
      </article>
    `;
  }

  function productCard(product) {
    return `
      <article class="product-card">
        <div class="media brand-cover"><img src="${product.image}" alt="${escapeHtml(product.code)}" loading="lazy"></div>
        <div class="content">
          <span class="model-code">${escapeHtml(product.code)}</span>
          <h3>${escapeHtml(product.title)}</h3>
          <p>${escapeHtml(product.copy)}</p>
          <div class="button-row" style="margin-top: 18px;"><a class="button" href="${withMessage(whatsappNumbers[0].url, product.code)}" target="_blank" rel="noopener">${escapeHtml(t.common.requestQuote)}</a></div>
        </div>
      </article>
    `;
  }

  function catalogCard(group) {
    const data = catalogData && catalogData[group.key];
    const count = data ? `${data.pageCount} pages` : group.subtitle;
    return `
      <article class="catalog-card">
        <a class="media brand-cover" href="#catalog-${group.key}"><img src="${group.image}" alt="${escapeHtml(group.title)}" loading="lazy"></a>
        <div class="content">
          <span class="section-kicker">${escapeHtml(count)}</span>
          <h3>${escapeHtml(group.title)}</h3>
          <p>${escapeHtml(t.catalogsPage.copy)}</p>
        </div>
      </article>
    `;
  }

  function renderGallerySection(title, keys) {
    return `
      <section class="section tight">
        <div class="inner">
          <div class="gallery-toolbar">
            <div>
              <span class="section-kicker">${escapeHtml(t.common.catalogs)}</span>
              <h2 class="section-title">${escapeHtml(title)}</h2>
            </div>
            <a class="button dark" href="${localUrl(state.lang, "contact.html")}">${escapeHtml(t.common.contactNow)}</a>
          </div>
          ${keys.map((key) => renderCatalogPages(key)).join("")}
        </div>
      </section>
    `;
  }

  function renderCatalogPages(key) {
    const data = catalogData && catalogData[key];
    if (!data) return "";
    const group = catalogGroups.find((item) => item.key === key);
    return `
      <div id="catalog-${key}" style="margin-top: 34px;">
        <span class="section-kicker">${escapeHtml(group ? group.title : data.label)}</span>
        <div class="catalog-page-grid" style="margin-top: 16px;">
          ${data.pages.map((page) => `
            <figure class="catalog-page brand-cover">
              <img src="${page.image}" alt="${escapeHtml((group ? group.title : data.label) + " " + page.page)}" loading="lazy">
              <figcaption>
                <span>${escapeHtml(t.common.page)} ${page.page}</span>
                <code>${escapeHtml(page.models && page.models.length ? page.models.slice(0, 3).join(" / ") : "CEDARIO")}</code>
              </figcaption>
            </figure>
          `).join("")}
        </div>
      </div>
    `;
  }

  function renderWhatsAppChoices() {
    return whatsappNumbers.map((item) => `
      <a class="whatsapp-choice" href="${withMessage(item.url)}" target="_blank" rel="noopener">
        <strong>WhatsApp</strong>
        <span>${escapeHtml(item.label)}</span>
      </a>
    `).join("");
  }

  function renderFloatingWhatsApp() {
    return `
      <div class="float-whatsapp" data-float>
        <button class="float-toggle" type="button" data-float-toggle aria-label="${escapeHtml(t.common.whatsapp)}">WA</button>
        <div class="float-panel">
          <div class="whatsapp-list">${renderWhatsAppChoices()}</div>
        </div>
      </div>
    `;
  }

  function renderCookieBar() {
    return `
      <div class="cookie-bar" data-cookie>
        <p>${escapeHtml(t.common.cookie)}</p>
        <button class="button dark" type="button" data-cookie-accept>${escapeHtml(t.common.accept)}</button>
      </div>
    `;
  }

  function renderFooter() {
    return `
      <footer class="footer">
        <div class="footer-inner">
          <div>
            <strong>${escapeHtml(t.brand)}</strong>
            <p>${escapeHtml(t.home.eyebrow)}</p>
          </div>
          <nav aria-label="Footer">
            <a href="${localUrl(state.lang, "privacy.html")}">${escapeHtml(t.common.privacy)}</a>
            <a href="${localUrl(state.lang, "contact.html")}">${escapeHtml(t.nav.contact)}</a>
          </nav>
        </div>
      </footer>
    `;
  }

  function bindEvents() {
    const language = document.querySelector("[data-language]");
    if (language) {
      language.addEventListener("change", (event) => {
        window.location.href = localUrl(event.target.value, pageFileForSwitch());
      });
    }

    const menu = document.querySelector("[data-menu]");
    if (menu) {
      menu.addEventListener("click", () => document.body.classList.toggle("nav-open"));
    }

    const float = document.querySelector("[data-float]");
    const floatToggle = document.querySelector("[data-float-toggle]");
    if (float && floatToggle) {
      floatToggle.addEventListener("click", () => float.classList.toggle("open"));
    }

    const cookie = document.querySelector("[data-cookie]");
    const accept = document.querySelector("[data-cookie-accept]");
    if (cookie && localStorage.getItem("cedarioCookieAccepted") !== "1") {
      cookie.classList.add("show");
    }
    if (accept) {
      accept.addEventListener("click", () => {
        localStorage.setItem("cedarioCookieAccepted", "1");
        cookie.classList.remove("show");
      });
    }
  }

  function pageFileForSwitch() {
    const valid = new Set(["index", "about", "products", "bathroom-cabinets", "toilets", "catalogs", "contact", "privacy"]);
    return valid.has(state.page) ? `${state.page === "index" ? "index" : state.page}.html` : "index.html";
  }

  function updateTitle() {
    const names = {
      index: t.brand,
      about: t.nav.about,
      products: t.nav.products,
      "bathroom-cabinets": t.series.cabinetsTitle,
      toilets: t.series.toiletsTitle,
      catalogs: t.nav.catalogs,
      contact: t.nav.contact,
      privacy: t.common.privacy
    };
    document.title = `${names[state.page] || t.brand} | ${t.brand}`;
  }

  function isActive(key) {
    if (key === "index") return state.page === "index";
    if (key === "products") return ["products", "bathroom-cabinets", "toilets"].includes(state.page);
    return state.page === key;
  }

  function withMessage(baseUrl, model) {
    const text = model ? `Hello CEDARIO, I want to inquire about model ${model}.` : "Hello CEDARIO, I want to inquire about your sanitary ware products.";
    return `${baseUrl}?text=${encodeURIComponent(text)}`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
  }
})();
